This is a repo demonstrating the code from the freecodecamp video.

It was inspired by the up to date [nft-mix](https://github.com/PatrickAlphaC/nft-mix)
