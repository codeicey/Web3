from scripts.helpful_scripts import deploy_mocks


def main():
    deploy_mocks()
